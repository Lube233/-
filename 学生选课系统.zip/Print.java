package GUI;
/**

 * @Author Kukdo

 * @Version 1.0

 */
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.JList;
public class Print extends JDialog {
	private final JPanel contentPanel = new JPanel();
	public static void main(String[] args) {
		try {
			Print dialog = new Print();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		}
		catch (Exception e) {
			System.out.println("nonono����������");;
		}
	}
	public Print() {
		setTitle("��ӡ�γ�");
		setBounds(100, 100, 650, 300);
		getContentPane().setLayout(new BorderLayout());	//���ֹ�������
		contentPanel.setLayout(new FlowLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		{  
			BufferedReader brs = new BufferedReader(new FileReader("D:\\JAVAʵ��\\numbers.txt"));
            String Student_num = brs.readLine();
            brs.close();
	        BufferedReader br = new BufferedReader(new FileReader("D:\\JAVAʵ��\\" + Student_num +".txt"));
	        String demo = br.readLine();
       	    br.close();
			lblNewLabel.setFont(new Font("����", Font.PLAIN | Font.ITALIC, 13));	//������
			contentPanel.add(lblNewLabel);	//
	        {   
	        	DefaultListModel listModel=new DefaultListModel(); 
	        	JList list = new JList(listModel);
	        	contentPanel.add(list);
	             String [] demoarray = demo.split(";");
	             for (int i=0; i<demoarray.length ;i++) {
	         		listModel.addElement(demoarray[i]);
	             }
	        }
	    
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
				okButton.addActionListener(new ActionListener(){
					public void actionPerformed(ActionEvent e) {
						System.exit(0);
					}
			});
		}
	}
	}
}
